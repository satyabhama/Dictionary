package com.concretepage.entity;

public class Word { 
    private long wordId;  
    private String word;
	public long getWordId() {
		return wordId;
	}
	public void setWordId(long wordId) {
		this.wordId = wordId;
	}
	public String getWord() {
		return word;
	}
	public void setWord(String word) {
		this.word = word;
	} 
	
} 