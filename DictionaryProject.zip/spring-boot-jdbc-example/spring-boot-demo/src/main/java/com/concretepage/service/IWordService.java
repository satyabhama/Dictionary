package com.concretepage.service;

public interface IWordService {
	boolean getWord(String word); 
     boolean addWord(); 
}

